/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package findrent;

import javax.swing.JOptionPane;

/**
 *
 * @author User
 */
public class FindRent {

    // just a simple code on two-demensional arrays
    
    
     
    public static void main(String[] args) {
        int[][] rents ={ {0,0,0,0,0},
                   { 0,500, 1000, 1500,2000}, // floor one
                   {0,2500,3000, 3500,4000}, // floor two
                   {0,4500,5000,5500,6000}, // floor three
                   {0,6500,7000,7500,8000}}; // floor four
        
        String entry;
        int floor;
        int bedrooms;
        
        entry=JOptionPane.showInputDialog(null, "Enter a floor number");
        // user has to enter any number between one and four
        floor=Integer.parseInt(entry);
        entry=JOptionPane.showInputDialog(null, "Enter number of bedrooms");
        //again user has to enter any number between one and four
        bedrooms=Integer.parseInt(entry);
        JOptionPane.showMessageDialog(null, " The rent for a " + bedrooms + " bedroom apartment on floor " + floor + " is R " + rents[floor][bedrooms]);
      
        
        
    
    }
    
}
