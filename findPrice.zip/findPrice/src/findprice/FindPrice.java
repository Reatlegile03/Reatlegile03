/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package findprice;

import javax.swing.JOptionPane;

/**
 *
 * @author User
 */
public class FindPrice {

    // just a simple code on parallel arrays
     
     
    public static void main(String[] args) {
        final int number_of_items=10;
         int[]validValues = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
         double[] prices = { 14000, 15000, 16000, 17000, 21000, 23000, 27000, 30000, 33000, 40000 };
         String strItem;
         int itemOrdered;
         double itemPrice=0.0;
         boolean isValidItem=false;
         
         strItem=JOptionPane.showInputDialog(null, " Enter the item number you want to order ");
         //user has to enter any number between 1 and 10, anything less than 1 nor more than 10,it will display the else statement
         
         itemOrdered=Integer.parseInt(strItem);
         for(int x=0 ; x< number_of_items && !isValidItem ; x++)
         {
           if(itemOrdered == validValues[x])
           {
               isValidItem=true;
               itemPrice = prices[x];
           }
         }
        if(isValidItem)   
      JOptionPane.showMessageDialog(null, " The price for item " + itemOrdered + " is R " + itemPrice );
                   
            else
      JOptionPane.showMessageDialog(null, " Sorry - The product you are looking for is currently Unavailable ");
    }
    
}
